var express = require('express');
var router = express.Router();
var leds = require('./leds');

router.get('/', function(req, res, next) {
  res.json({message: 'Sensors API is running!'});
});

router.route('/leds')
  .get(leds.getAllLeds)
  .post(leds.addLed);

router.route('/leds/:id')
  .get(leds.getLedById)
  .post(leds.updateLed)
  .delete(leds.deleteLedById);


module.exports =router;
