var express = require('express');
var router = express.Router();
var bookmodel = require('./bookmodel');
// var sensors = require('./led');
router.get('/', function(req, res, next) {
  res.json({message: 'Book API is running!'});
});

router.route('/books')
  .get(bookmodel.getAllBooks)
  .post(bookmodel.addBook);

router.route('/books/:id')
  .get(bookmodel.getBookById)
  .post(bookmodel.updateBook)
  .delete(bookmodel.deleteBookById);

  router.route('/led')
    .get(bookmodel.getLed)
    .post(bookmodel.updateLed);
    router.route('/led/:switch')
      .get(bookmodel.getLedSw)
      .post(bookmodel.updateLedSw);

module.exports = router;
