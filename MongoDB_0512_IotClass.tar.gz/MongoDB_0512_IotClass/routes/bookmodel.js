var mongoose = require('mongoose');

mongoose.connect('mongodb://guest:guest@192.168.2.29/pinkaru');

var Bookscheme = new mongoose.Schema({
  title : String,
  author : String,
  name : String
});
var LedSchema = new mongoose.Schema({
  type : String,
  name : String,
  switch : String
});
var ledmodel = mongoose.model('LED',LedSchema);
var BookModel = mongoose.model('Book',Bookscheme);
exports.getAllBooks =function(req,res){
  console.log('Get /api/books');

  return BookModel.find(function  (err,books){
    if(err){
      console.log(err);
      return res.send(err);
    }

    return res.send(books);
  });
};
var LED =new ledmodel();
exports.getBookById = function(req,res){
  return BookModel.findById(req.params.id, function (err, book) {
    res.send(book);

  });
};

exports.addBook = function(req,res){
  console.log("adding a book:"+req.body.title);
  var book = new BookModel();
  book.title= req.body.title;
  book.author= req.body.author;
  book.year= req.body.year;
  return book.save(function (err) {
    if(err){
      console.log(err);
      return res.send(err);
    }

    return res.send(book);
  });
};
exports.updateBook=function(req,res){
  BookModel.findById(req.params.id,function(err,book){
    if(err)
      return res.send(err);
    book.title = req.body.title;
    book.update({id:req.params.id,title : req.body.title},function(err,book){
      if(err)
        return res.send(err);
      return res.json({title: book.title,message:'Book updated!'});
    });
  });
};

exports.deleteBookById=function(req,res){
  console.log("Deleting book:",req.params.id);
  return BookModel.remove({_id:req.params.id},function(err, book){
    if(err){
      console.log(err);
    return res.send(err);
  }else{
    return res.json({message:"Id("+req.params.id+")"});
  }

  });
};
  var name = "57341c1ae02f7575112b45d7";
exports.getLed =function(req,res){

  console.log("Deleting book:",req.params.id);
  return ledmodel.findById(name,function(err, LED){
    if(err){
      console.log(err);
    return res.send(err);
  }else{
    return res.json(LED);
  }

  });
};
exports.updateLed=function(req,res){
  console.log("adding a book:"+req.body.type);

  LED.type= req.body.type;
  LED.name= req.body.name;
  LED.switch= req.body.switch;
  return ledmodel.save(name,function (err) {
    if(err){
      console.log(err);
      return res.send(err);
    }
    var msg=String;
     ledmodel.findById(name,function(err, msg){

     });
    return res.send(msg);
  });
};
exports.getLedSw =function(req,res){

  console.log("Deleting book:",req.params.switch);
  LED.switch = req.params.switch;
  return ledmodel.update({_id:name ,switch : LED.switch},function(err, LED){
    if(err){
      console.log(err);
    return res.send(err);
  }else{

    return res.send(LED);
  }

  });
};
exports.updateLedSw=function(req,res){
  console.log("adding a book:"+req.body.type);


  LED.switch= req.body.switch;
  return led.save(function (err) {
    if(err){
      console.log(err);
      return res.send(err);
    }

    return res.send(LED);
  });
};
