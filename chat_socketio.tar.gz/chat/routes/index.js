var express = require('express');
var router = express.Router();

var os = require('os');

var interfaces = os.networkInterfaces();
var addresses = [];
for (var k in interfaces) {
  for (var k2 in interfaces[k]) {
    var address = interfaces[k][k2];
    if (address.family === 'IPv4' && !address.internal) {
      addresses.push(address.address);
  }
}
}

/* GET home page. */
router.get('/', function(req, res, next) {
  console.log(addresses);
  res.render('index');
});

module.exports = router;
