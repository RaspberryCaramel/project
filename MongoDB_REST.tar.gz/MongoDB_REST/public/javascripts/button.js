function clicked(){

var buttonElement = document.getElementById("toggle_btn");
// buttonElement.addEventListener("click",changeBg);

buttonElement=document.addEventListener("click",changeBg);

console.log("click");
}
clicked();
