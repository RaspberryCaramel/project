function clicked(index){
var name = "toggle_btn"+index;
var buttonElement = document.getElementById(name);
// buttonElement.addEventListener("click",changeBg);

buttonElement=document.addEventListener("click",changeBg(index));

console.log("click");
}
clicked();
