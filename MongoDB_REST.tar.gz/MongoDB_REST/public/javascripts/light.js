var xmlHttp=null;

if(window.XMLHttpRequest){
  xmlHttp=new XMLHttpRequest();
}else{
  xmlHttp=new ActiveXObject("Microsoft.XMLHTTP");
}

  function changeBg(index, id){
    var name = 'img_light'+index;
    var sw;
     var imgElement = document.getElementById(name);
      // var frm = document.getElementById("frm1");
      console.log(name);
      console.log(imgElement.src);

      if(imgElement.src.match("light_off")){
        imgElement.src='/images/light_on.png';
        sw="on";
      }
      else{
        imgElement.src='/images/light_off.png';
        sw="off";
      }
    var params="switch="+sw;
    xmlHttp.open('PUT','/api/sensors/leds/'+id,true);
    xmlHttp.setRequestHeader('Content-Type',
      'application/x-www-form-urlencoded');
    xmlHttp.onreadystatechange= function(){
      if(xmlHttp.readyState==4&&xmlHttp.status==200){
          console.log(xmlHttp.responseText);
      }
    };
    xmlHttp.send(params);
}

function resetSelect(index,length){
  for(i=0;i<length;i++){
    if(length===index)continue;
    document.getElementById('select_'+index).selected=null;
  }
}
function showLi(index,length){
  for(i=0;i<length;i++){
    if(i==index)
     document.getElementById('li_'+i).style='display:on';
    else {
      document.getElementById('li_'+i).style='display:none';
    }
  }
}
// changeBg();
