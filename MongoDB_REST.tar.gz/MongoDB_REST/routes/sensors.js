var express = require('express');
var router = express.Router();
var leds = require('./leds');

router.route('/')
  .get(function(req,res,next){
    res.render('sensors',{type:'sensors',name : 'user',message:'sensors api is running!'});
  });

router.route('/leds')
  .get(leds.getAllLeds)
  .post(leds.postLed);

router.route('/leds/:id')
  .get(leds.getLedById)
  .put(leds.putLed)
  .delete(leds.deleteLedById);


module.exports = router;
