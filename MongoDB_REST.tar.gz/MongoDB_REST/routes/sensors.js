var express = require('express');
var router = express.Router();
var leds = require('./leds');
var dhts = require('./dhts');



router.route('/leds')
  .get(leds.getAllLeds)
  .post(leds.postLed);

router.route('/leds/:id')
  .get(leds.getLedById)
  .put(leds.putLed)
  .delete(leds.deleteLedById);

router.route('/dhts')
    .get(dhts.getAllDhts)
    .post(dhts.postDht);


router.route('/dhts/:id')
    .get(dhts.getDhtById)
    .put(dhts.putDht)
    .delete(dhts.deleteDhtById);

module.exports = router;
