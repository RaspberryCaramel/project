var express = require('express');
var router = express.Router();
var leds = require('./leds');

router.route('/')
  .get(function(req,res,next){
    res.render('sensors',{type:sensors,name : 'user',message:'sensors api is running!'});
  });

router.route('/leds')
  .get(leds.getAllLeds)
  ;


module.exports = router;
