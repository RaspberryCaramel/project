var express = require('express');
var router = express.Router();
var sensors = require('./sensors');

// router.route('/sensors').get(function(r,s){
//   s.send('ok');
// });

module.exports = router;
