var express = require('express');
var router = express.Router();
var sensors = require('./sensors');

express.use('/sensors',sensors);

module.exports = router;
