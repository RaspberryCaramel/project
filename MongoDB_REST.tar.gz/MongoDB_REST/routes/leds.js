
var mongoose = require('mongoose');


//mongoose connect exam
//mongoose.connect('mongodb://<id>:<pw>@ip/<db name>');
mongoose.connect('mongodb://guest:guest@192.168.219.159/Iot');

//Database model define
var LedSchema = new mongoose.Schema({
  type : String,
  name : String,
  switch : String
});

var LedModel= mongoose.model('led',LedSchema);

//Method


//get default , parameter : id
exports.getAllLeds = function(req,res,next){
  console.log('Get /api/leds');
  return LedModel.find(function(err,leds){
    if(err){
      console.log(err);
      return res.send(err);
    }
    return res.send(leds);
  });
};

exports.getLedById = function(req,res){
  return LedModel.findById(req.params.id,function(err,led){
    if(err){
      console.log(err);
      return res.send(err);
    }
    return res.send(led);
  });

};

exports.postLed = function(req,res,next){
  var Led = new LedModel();
  Led.type = req.body.type;
  Led.name = req.body.name;
  Led.switch = req.body.switch;
  return Led.save(function(err,led){
    if(err){
      console.log(err);
      return res.send(err);
    }
    return res.send(led);
  });
};

exports.putLed=function(req,res,next){
  var Led=new LedModel();
  var aa = String;
  LedModel.findById(req.params.id,function(err,led){

  console.log(jsData=JSON.stringify(led));

  });

  var conditions = {_id: req.params.id },
     update = { $set : {
       type:req.body.type,
       name:req.body.name,
       switch: req.body.switch}
      };
  return LedModel.update(conditions,update,function(err,led){
    if(err){
      console.log(err);
      return res.send(err);
    }
    return res.send(led);
  });
};
exports.deleteLedById = function(req,res){
  return LedModel.remove({_id:req.params.id},function(err,led){
    if(err){
      console.log(err);
      return res.send(err);
    }
    return res.send(led);
  });
};
