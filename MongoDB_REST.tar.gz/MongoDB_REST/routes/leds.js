
var mongoose = require('mongoose');

//mongoose connect exam
//mongoose.connect('mongodb://<id>:<pw>@ip/<db name>');

//Database model define
var LedSchema = new mongoose.Schema({
  type : String,
  name : String,
  switch : String
});

var LedModel= mongoose.model('led',LedSchema);

//Method
var Led = new LedModel();


exports.getAllLeds = function(req,res,next){
  console.log('Get /api/leds');
  next(queryLed);
  return LedModel.find(function(err,leds){
    if(err){
      console.log(err);
      return res.send(err);
    }
    return res.send(leds);
  });
};

exports.getLedBy = function(req,res){
  return LedModel.find(req.params.id,function(err,led){
    if(err){
      console.log(err);
      return res.send(err);
    }
    return res.send(led);
  });
};

queryLed=function(req,res){
  Led.type = req.query.type,
  Led.name = req.query.name,
  Led.switch = req.query.switch;
};
