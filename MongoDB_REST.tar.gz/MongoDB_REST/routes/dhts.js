
var mongoose = require('mongoose');


//mongoose connect exam
//mongoose.connect('mongodb://<id>:<pw>@ip/<db name>');
mongoose.createConnection('mongodb://guest:guest@192.168.2.29/sensors');

//Database model define
var DhtSchema = new mongoose.Schema({
  type : String,
  name : String,
  switch : String,
  humidity :String,
  temperate : String
});

var DhtModel= mongoose.model('dht',DhtSchema);

//Method


//get default , parameter : id
exports.getAllDhts = function(req,res,next){
  console.log('Get /api/Dhts');
  return DhtModel.find(function(err,Dhts){
    if(err){
      console.log(err);
      return res.send(err);
    }
    return res.send(Dhts);
  });
};

exports.getDhtById = function(req,res){
  return DhtModel.findById(req.params.id,function(err,Dht){
    if(err){
      console.log(err);
      return res.send(err);
    }
    return res.send(Dht);
  });

};

exports.postDht = function(req,res,next){
  var Dht = new DhtModel();
  Dht.type = req.body.type;
  Dht.name = req.body.name;
  Dht.switch = req.body.switch;
  Dht.humidity = req.body.humidity;
  Dht.temperate = req.body.temperate;
  return Dht.save(function(err,Dht){
    if(err){
      console.log(err);
      return res.send(err);
    }
    return res.send(Dht);
  });
};

exports.putDht=function(req,res,next){
  var Dht=new DhtModel();
  var aa = String;
  DhtModel.findById(req.params.id,function(err,Dht){

  console.log(jsData=JSON.stringify(Dht));

  });

  var conditions = {_id: req.params.id },
     update = { $set : {
       type:req.body.type,
       name:req.body.name,
       switch: req.body.switch,
       humidity : req.body.humidity,
       temperate : req.body.temperate
     }
      };
  return DhtModel.update(conditions,update,function(err,Dht){
    if(err){
      console.log(err);
      return res.send(err);
    }
    return res.send(Dht);
  });
};
exports.deleteDhtById = function(req,res){
  return DhtModel.remove({_id:req.params.id},function(err,Dht){
    if(err){
      console.log(err);
      return res.send(err);
    }
    return res.send(Dht);
  });
};
